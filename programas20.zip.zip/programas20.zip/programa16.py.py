print("Escribe un programa que solicite al usuario su peso y altura calcule el indice de masa corporal")

print("peso,normal,sobrepeso,obesisdad")

print("=======================================/N")
altura = float(input("Ingrese su altura en metros: "))
peso = float(input(" Ingrese su peso en kilogramos: "))

imc = peso / (altura ** 2)

if imc < 18.5:
    clasificacion = "Bajo peso"
elif imc > 18.5 and imc <= 24.9:
    clasificacion = "normal"
elif imc > 25 and imc <= 29.9:
    clasificacion = "sobrepeso"
else:
    clasificacion = "obesidad"
    
print(f"Su IMC es:{ imc :.2f}, lo que indica que tiene {clasificacion}.")
print("Su IMC es:" + str(round(imc,2)) + ",lo que indica que tiene" + clasificacion)