print("Escribe un programa que solicite la edad del usuario y determine el tipo de licencia de condcir que puede obtener")

print("=================================================================================================")

edad = int(input("introduce tu edad: "))
if 16 <= edad <= 17:
    print("licencia de menor")
elif 18 <= edad <= 65:
    print("licencia de adulto ")
else:
    print("licencia de adulto mayor")