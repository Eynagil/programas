print("===================================================")

print("Escribe un programa que solicite el precio de un producto y determine el precio final")

print("====================================================")
precio = int(input("Ingrese el presio del producto: "))
if precio > 100:
    descuento = precio * 0.10
    precio_final = precio - descuento
    print(f"Se aplico un descuento del 10%. El precio final es: ${precio_final:.2f}")
else:
    precio_final = preio
    print(f"El precio es menor o igual a $100. El precio final es:${precio_final:.2f}")