print("Escribe un programa que solicite la edad del usuario y dtermine si es un adolecente")

print("====================================================================================")
edad = int(input("Ingrese la edad: "))

if edad >= 13 and edad <= 19:
 print("es adolencente")
  
else:
  print("no eres adolecente ")