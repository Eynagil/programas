print("Escribe un programa que solicite la dsitancia recorrida en kilometros y calcule la tarifa del taxi")

print("===========================================================================================")

ki=float(input("ingrese el monte:"))

if ki < 10:
    tarifa=ki * 2.50
else:
    tarifa= 10 * 2.50 +( ki -10) *2.00
    print (f"tarifa del taxi :", ki)