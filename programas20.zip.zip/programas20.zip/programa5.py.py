print("Escribe un programa que solicite una palabra al usuario y determine si tiene mas de 5 letras")

print("son 5 letras")

print("========================================================/N")

p = input("Ingresa la palabra: ")
c = len(p.strip())
if c >= 5:
    print("Son 5 letras")
else:
    print("Menos de 5")