print("Escribe un programa que solicite al usuario dos numero y determine cual es mayor o")

print("son iguales")

print("=========================================================================\N")

a= int(input("ingrese un numero :"))
b= int(input("ingrese un segundo numero :"))
if a==b:
    print("ambos son iguales")
elif a>b:
    print(f"el numero mayor es {a}")
    print(f"el numero menor es {b}")
elif a<b:
    print(f"el numero mayor es {b}")
    print(F"el numero menor es {a}")