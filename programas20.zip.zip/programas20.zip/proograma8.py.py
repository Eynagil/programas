print("====================================")

print("Escribe un programa que solicite al usuario un numero y determine si esta entre 1 y100 inclusive")

print("===================================")
numero=int(input("escribe un numero"))

if numero>=1 and numero<=100:
    print(f"el numero{numero} esta dentro del rango")
else:
    print(f"el numero{numero}no esta dentro del rango")
    