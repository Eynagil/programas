print("Escribe un programa que solicite la edad del usuario un numero y determine si es multiplo de 5")

print("===================================================================================")
num = int(input("agrega un numero entero: "))
if num % 5==0:
	print("el numero es multiplo de 5")

else:
	print("no es multiplo de 5")