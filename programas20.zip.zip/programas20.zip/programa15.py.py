experiencia = float(input("Ingrese los años de experiencia del trabajador: "))

if experiencia < 2:
    categoria = "Junior"
elif experiencia <= 5:
    categoria = "Semi-Senior"
else:
    categoria = "Senior"

print("La categoría del trabajador es: ",categoria)
