print("Escribe un programa que solicite al usuario un numero y determine si es positivo,negativo o cero")

print("=======================================================================")
print("escribe el numero: ")
n = int(input())
if n>0:
    print("es positivo")

elif n<0:
    print("es negativo")

else:
    print("es cero")