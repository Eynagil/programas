print("Escribe un programa que solicite  una letra al usuarrio y determine si es vocal")
 
print("La letra ingresada es una letra:")

print("==================================================================================")

letra = input("introduce una letra")
if letra in ('a e i o u'):
    print("La letra ingreasada en una vocal.")
else:
    print("La letra ingresada no es una vocal.")