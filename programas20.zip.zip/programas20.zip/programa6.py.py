print("========================================")

print("Escribe un programa que solicite la edad del usuario y clasifique la edad en una de las siguientes categoria")

print("========================================")
edad = int(input("ingrese edad actual: "))

if edad < 13:
    print("niños")

elif edad < 19 and edad >=13:
    print("adolecente")

elif edad >= 60:
    print("adulto; ",edad)
