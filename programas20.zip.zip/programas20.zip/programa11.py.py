print("=====================================================================")

print("Escribe un programa que solicite un numero al usuario y determine si es un numero primo")

print("========================================================================")
numero = int(input("Ingrese un número entero positivo: "))

if es_primo(numero):
    print(numero, "es un número primo.")
else:
    print(numero, "no es un número primo.")
    