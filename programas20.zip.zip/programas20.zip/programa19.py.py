print("==================================================================================================")

print("Escribe un progrma que solicite un nombre al usuario y determine si el nombre es corto,mediano,largo")

print("==================================================================================================")
nombre = int(input("Introduce un nombre: "))

longitud_no = len(nombre)


if longitud_no < 5:
    categoria = "corto"
elif longitud_no >= 5 and longitud_no <= 8:
    categoria = "mediano"
else:
    categoria = "largo"


print(f"El nombre {nombre} tiene {longitud_no} letras y es de longitud {categoria}.")