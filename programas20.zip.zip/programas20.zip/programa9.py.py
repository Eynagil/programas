print("==============================================================================")

print("Escribe un programa que solicite un caracter al usuario y determine si es una letra")

print("==============================================================================")
caracter =int(input("ingrese un caracter"))

if len(caracter) !=l:
    print("por favor, ingrese un caracter")
elif caracter.isalpha:
    print(f"el caracter'(caracter)' es una letra")
elif caracter.isdigit:
    print(f"el caracter'(caracter)' es una digito")
else:
    print(f"el caracter'(caracter)' no es ni una letra ni digito")